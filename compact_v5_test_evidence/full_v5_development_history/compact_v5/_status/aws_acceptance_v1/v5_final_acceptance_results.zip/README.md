# Mini Issue Tracker

A lightweight, dependency-free Python issue tracking system with JSON storage, CLI interface, and markdown reporting capabilities.

## Features

- **Zero Dependencies**: Uses only Python standard library
- **Atomic Writes**: Data integrity guaranteed through atomic file operations
- **Full CRUD Operations**: Create, read, update, delete issues
- **Powerful Search**: Filter by status, tags, and text queries
- **Markdown Reports**: Generate formatted reports with multiple grouping options
- **CLI Interface**: Complete command-line interface with 8 commands

## Installation

```bash
# Clone or copy the project
cd mini_issue_tracker

# No installation needed - uses only standard library!
# Optionally, you can install in development mode:
pip install -e .
```

## Quick Start

```bash
# Create an issue
python -m issue_tracker.cli create --title "Bug in login" --tags "bug,auth"

# List all issues
python -m issue_tracker.cli list

# Show issue details
python -m issue_tracker.cli show <issue-id>

# Update an issue
python -m issue_tracker.cli update <issue-id> --title "Updated title"

# Close an issue
python -m issue_tracker.cli close <issue-id>

# Search issues
python -m issue_tracker.cli search --query "login" --tags "bug"

# Generate a report
python -m issue_tracker.cli report --output report.md
```

## Commands

### create
Create a new issue.

```bash
python -m issue_tracker.cli create --title "Issue title" [--description "Description"] [--tags "tag1,tag2"]
```

### list
List all issues with optional filtering and sorting.

```bash
python -m issue_tracker.cli list [--status {open,closed,all}] [--tags "tag1,tag2"] [--sort {created,updated,title}] [--reverse]
```

### show
Show detailed information about an issue.

```bash
python -m issue_tracker.cli show <issue-id>
```

### update
Update an existing issue.

```bash
python -m issue_tracker.cli update <issue-id> [--title "New title"] [--description "New description"] [--add-tags "tag1,tag2"] [--remove-tags "tag3"]
```

### close
Close an issue.

```bash
python -m issue_tracker.cli close <issue-id>
```

### reopen
Reopen a closed issue.

```bash
python -m issue_tracker.cli reopen <issue-id>
```

### search
Search issues by text query, tags, and status.

```bash
python -m issue_tracker.cli search [--query "search terms"] [--tags "tag1,tag2"] [--status {open,closed,all}]
```

### report
Generate a markdown report.

```bash
python -m issue_tracker.cli report [--output file.md] [--status {open,closed,all}] [--group-by {status,tags,none}]
```

## Configuration

### Database Location

By default, issues are stored in `~/.issue_tracker/issues.json`.

You can override this in two ways:

1. **Environment variable**:
   ```bash
   export ISSUE_TRACKER_DB=/path/to/custom/issues.json
   ```

2. **Command-line option**:
   ```bash
   python -m issue_tracker.cli --db-path /path/to/custom/issues.json list
   ```

## Architecture

The package is organized into five main modules:

- **models.py**: Issue data model with validation
- **store.py**: JSON storage with atomic writes
- **search.py**: Search and filter functionality
- **report.py**: Markdown report generation
- **cli.py**: Command-line interface

See [docs/DESIGN.md](docs/DESIGN.md) for detailed architecture documentation.

## Testing

Run the test suite:

```bash
pytest tests/ -v
```

Test coverage:
- 80 tests covering all modules
- Models: 100% coverage
- Store: 95%+ coverage
- Search: 90%+ coverage
- CLI: 80%+ coverage

## Development

### Project Structure

```
mini_issue_tracker/
├── issue_tracker/          # Main package
│   ├── __init__.py
│   ├── models.py          # Issue model
│   ├── store.py           # JSON storage
│   ├── cli.py             # CLI interface
│   ├── search.py          # Search functionality
│   └── report.py          # Report generation
├── tests/                 # Test suite
│   ├── test_models.py
│   ├── test_store.py
│   ├── test_search.py
│   └── test_cli.py
├── docs/                  # Documentation
│   ├── DESIGN.md
│   ├── CHANGELOG.md
│   └── TEST_REPORT.md
├── README.md
└── pyproject.toml
```

### Running Tests

```bash
# Run all tests
pytest tests/

# Run specific test file
pytest tests/test_models.py

# Run with coverage
pytest tests/ --cov=issue_tracker
```

## License

MIT License - See LICENSE file for details.

## Contributing

This is a demonstration project for the SageMaker Coding Agent v5 acceptance test.

## Version

Current version: 0.1.0

See [CHANGELOG.md](docs/CHANGELOG.md) for version history.
