# mini_issue_tracker Design Document

## 1. Overview

A lightweight, dependency-free Python issue tracking system with JSON storage, CLI interface, and markdown reporting capabilities.

### Core Principles
- **Zero external dependencies**: Python standard library only
- **Data integrity**: Atomic writes prevent corruption
- **Simplicity**: Straightforward data structures and algorithms
- **Extensibility**: Modular design for future enhancements

---

## 2. Module Architecture

### 2.1 `issue_tracker/models.py`
**Responsibility**: Issue data model with validation and serialization

**Key Components**:
- `Issue` class with immutable ID
- Field validation (required fields, status enum)
- Serialization to/from dict
- Timestamp management (ISO 8601 format)

**Data Structure**:
```python
Issue:
  - id: str (UUID4)
  - title: str (required, 1-200 chars)
  - description: str (optional, max 10000 chars)
  - status: str (enum: "open", "closed")
  - created_at: str (ISO 8601 timestamp)
  - updated_at: str (ISO 8601 timestamp)
  - tags: list[str] (lowercase, alphanumeric + hyphen/underscore)
```

**Validation Rules**:
- Title: non-empty, stripped, max 200 chars
- Status: must be "open" or "closed"
- Tags: lowercase, no duplicates, valid characters only
- Timestamps: auto-generated, immutable created_at

---

### 2.2 `issue_tracker/store.py`
**Responsibility**: Persistent JSON storage with atomic write guarantees

**Key Components**:
- `JSONStore` class managing single JSON file
- Atomic write implementation
- Auto-initialization of storage file
- Thread-safe operations (single-process assumption)

**Storage Format**: **Dict of dicts by ID**
```json
{
  "uuid-1": {
    "id": "uuid-1",
    "title": "Bug in login",
    "description": "...",
    "status": "open",
    "created_at": "2026-05-15T10:30:00Z",
    "updated_at": "2026-05-15T10:30:00Z",
    "tags": ["bug", "auth"]
  },
  "uuid-2": { ... }
}
```

**Rationale for dict-by-ID**:
- O(1) lookup by ID
- Simpler updates (no list scanning)
- Natural JSON structure for key-value access
- Easy to check for ID conflicts

**Atomic Write Algorithm**:
```
1. Serialize data to JSON string
2. Create temp file in same directory as target (tempfile.NamedTemporaryFile)
3. Write JSON to temp file
4. Flush and fsync (file.flush() + os.fsync(file.fileno()))
5. Close temp file
6. os.replace(temp_path, target_path)  # Atomic on POSIX and Windows
7. On error: clean up temp file
```

**Key Methods**:
- `load() -> dict[str, dict]`: Read and parse JSON
- `save(data: dict[str, dict])`: Atomic write
- `get(issue_id: str) -> dict | None`: Retrieve single issue
- `list_all() -> list[dict]`: Get all issues
- `add(issue_dict: dict)`: Add new issue
- `update(issue_id: str, updates: dict)`: Update existing issue
- `delete(issue_id: str)`: Remove issue

---

### 2.3 `issue_tracker/cli.py`
**Responsibility**: Command-line interface using argparse

**Command Structure**:
```
issue-tracker <command> [options]

Commands:
  create              Create new issue
  list                List all issues
  show <id>           Show issue details
  update <id>         Update issue fields
  close <id>          Close an issue
  reopen <id>         Reopen a closed issue
  search              Search issues
  report              Generate markdown report
```

**Command Details**:

**`create`**:
```
--title TEXT (required)
--description TEXT (optional)
--tags TAG1,TAG2,... (optional)
```

**`list`**:
```
--status {open,closed,all} (default: all)
--tags TAG1,TAG2,... (filter by tags)
--sort {created,updated,title} (default: created)
--reverse (reverse sort order)
```

**`show`**:
```
<id> (positional, required)
```

**`update`**:
```
<id> (positional, required)
--title TEXT (optional)
--description TEXT (optional)
--add-tags TAG1,TAG2,... (optional)
--remove-tags TAG1,TAG2,... (optional)
```

**`close`** / **`reopen`**:
```
<id> (positional, required)
```

**`search`**:
```
--query TEXT (search in title and description)
--tags TAG1,TAG2,... (filter by tags)
--status {open,closed,all} (default: all)
```

**`report`**:
```
--output FILE (default: stdout)
--status {open,closed,all} (default: all)
--group-by {status,tags,none} (default: status)
```

**CLI Architecture**:
- Main parser with subparsers for each command
- Each command maps to a handler function
- Handlers coordinate between store, models, search, report modules
- Pretty-printed output (tabular for lists, formatted for details)
- Exit codes: 0 (success), 1 (user error), 2 (system error)

---

### 2.4 `issue_tracker/search.py`
**Responsibility**: Search and filter functionality

**Implementation Strategy**: **Filter-based (no indexing)**

**Rationale**:
- Simple implementation
- No index maintenance overhead
- Sufficient performance for small-to-medium datasets (<10k issues)
- Standard library only (no search engine dependencies)

**Search Algorithm**:
```
1. Load all issues from store
2. Apply filters sequentially:
   a. Status filter (if specified)
   b. Tag filter (if specified) - issue must have ALL specified tags
   c. Text search (if specified) - case-insensitive substring match
3. Return matching issues
```

**Text Search**:
- Case-insensitive
- Search in: title, description
- Simple substring matching (no tokenization/stemming)
- Multiple terms: AND logic (all terms must match)

**Key Functions**:
- `search_issues(store, query=None, tags=None, status=None) -> list[dict]`
- `filter_by_status(issues, status) -> list[dict]`
- `filter_by_tags(issues, tags) -> list[dict]`
- `filter_by_text(issues, query) -> list[dict]`

---

### 2.5 `issue_tracker/report.py`
**Responsibility**: Markdown report generation

**Report Structure**:
```markdown
# Issue Tracker Report

Generated: 2026-05-15 10:30:00

## Summary
- Total Issues: 42
- Open: 15
- Closed: 27

## Issues by Status

### Open Issues (15)

#### [uuid-1] Bug in login
**Status**: open  
**Created**: 2026-05-10 14:20:00  
**Updated**: 2026-05-12 09:15:00  
**Tags**: bug, auth

Description of the issue...

---

### Closed Issues (27)
...
```

**Grouping Options**:
- **By status**: Open issues first, then closed
- **By tags**: Group by primary tag (first tag), then "Untagged"
- **None**: Chronological order (newest first)

**Key Functions**:
- `generate_report(issues, group_by='status') -> str`
- `format_issue_section(issue) -> str`
- `generate_summary(issues) -> str`

---

## 3. Data Flow

### Create Issue Flow
```
CLI (create) 
  → Parse arguments
  → Issue.create(title, description, tags)
  → Validate fields
  → Generate UUID and timestamps
  → Store.add(issue.to_dict())
  → Atomic write to JSON
  → Print confirmation with ID
```

### Update Issue Flow
```
CLI (update)
  → Parse arguments
  → Store.get(issue_id)
  → Issue.from_dict(stored_data)
  → Issue.update(title=..., tags=...)
  → Update updated_at timestamp
  → Store.update(issue_id, issue.to_dict())
  → Atomic write to JSON
  → Print confirmation
```

### Search Flow
```
CLI (search)
  → Parse arguments
  → search_issues(store, query, tags, status)
  → Load all issues
  → Apply filters
  → Return matches
  → Format and print results
```

---

## 4. Error Handling Strategy

### Error Categories

**1. User Errors** (exit code 1):
- Invalid issue ID (not found)
- Invalid field values (validation errors)
- Missing required arguments
- Invalid command syntax

**2. System Errors** (exit code 2):
- File I/O errors (permissions, disk full)
- JSON parse errors (corrupted data)
- Unexpected exceptions

### Error Handling Approach

**Models Layer**:
- Raise `ValueError` for validation errors
- Include descriptive error messages
- No silent failures

**Store Layer**:
- Raise `FileNotFoundError` for missing storage
- Raise `JSONDecodeError` for corrupted data
- Raise `OSError` for I/O failures
- Clean up temp files on write failure

**CLI Layer**:
- Catch exceptions from lower layers
- Print user-friendly error messages to stderr
- Exit with appropriate code
- Use try/except around main command handlers

**Example**:
```python
try:
    issue = Issue.create(title=args.title, ...)
except ValueError as e:
    print(f"Error: {e}", file=sys.stderr)
    sys.exit(1)
except OSError as e:
    print(f"Storage error: {e}", file=sys.stderr)
    sys.exit(2)
```

---

## 5. Key Algorithms

### 5.1 Atomic Write Implementation

```python
def save(self, data: dict[str, dict]) -> None:
    """Atomically write data to JSON file."""
    import tempfile
    import json
    import os
    
    # Serialize first (fail early if not serializable)
    json_str = json.dumps(data, indent=2, ensure_ascii=False)
    
    # Create temp file in same directory (same filesystem)
    dir_path = os.path.dirname(self.file_path)
    
    with tempfile.NamedTemporaryFile(
        mode='w',
        encoding='utf-8',
        dir=dir_path,
        delete=False,
        suffix='.tmp'
    ) as tmp_file:
        tmp_path = tmp_file.name
        try:
            # Write data
            tmp_file.write(json_str)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())  # Force write to disk
            
            # Close before rename (Windows requirement)
            tmp_file.close()
            
            # Atomic replace (POSIX and Windows 3.3+)
            os.replace(tmp_path, self.file_path)
            
        except Exception:
            # Clean up temp file on error
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
```

**Why this works**:
- `os.replace()` is atomic on both POSIX and Windows (Python 3.3+)
- Temp file in same directory ensures same filesystem (required for atomic rename)
- `fsync()` ensures data is on disk before rename
- Cleanup on error prevents temp file accumulation

### 5.2 Tag Filtering (AND logic)

```python
def filter_by_tags(issues: list[dict], required_tags: list[str]) -> list[dict]:
    """Return issues that have ALL required tags."""
    required_set = set(tag.lower() for tag in required_tags)
    return [
        issue for issue in issues
        if required_set.issubset(set(issue.get('tags', [])))
    ]
```

### 5.3 Text Search (Multi-term AND)

```python
def filter_by_text(issues: list[dict], query: str) -> list[dict]:
    """Return issues matching all query terms (case-insensitive)."""
    terms = query.lower().split()
    results = []
    
    for issue in issues:
        searchable = (
            issue.get('title', '') + ' ' + 
            issue.get('description', '')
        ).lower()
        
        if all(term in searchable for term in terms):
            results.append(issue)
    
    return results
```

---

## 6. Testing Strategy

### 6.1 Unit Tests

**`tests/test_models.py`**:
- Issue creation with valid/invalid data
- Field validation (title length, status enum, tag format)
- Serialization (to_dict, from_dict round-trip)
- Timestamp generation and immutability
- Update operations

**`tests/test_store.py`**:
- File initialization (create if not exists)
- Atomic write (verify temp file cleanup)
- CRUD operations (add, get, update, delete)
- Concurrent write simulation (multiple rapid writes)
- Corrupted JSON handling
- Empty store handling

**`tests/test_search.py`**:
- Status filtering
- Tag filtering (single, multiple, none)
- Text search (single term, multiple terms, case-insensitive)
- Combined filters
- Empty result sets

**`tests/test_cli.py`**:
- End-to-end command execution
- Argument parsing
- Error messages and exit codes
- Output formatting
- Command chaining (create → update → close → reopen)

### 6.2 Test Coverage Goals

- Models: 100% (critical validation logic)
- Store: 95%+ (atomic write paths)
- Search: 90%+
- Report: 85%+
- CLI: 80%+ (focus on logic, not argparse internals)

---

## 7. Configuration and Defaults

### Storage Location
- Default: `~/.issue_tracker/issues.json`
- Override via environment variable: `ISSUE_TRACKER_DB`
- CLI option: `--db-path PATH` (global option)

### Default Behaviors
- New issues: status="open", tags=[]
- List command: show all statuses, sort by created_at descending
- Search: case-insensitive, all statuses
- Report: group by status, output to stdout
