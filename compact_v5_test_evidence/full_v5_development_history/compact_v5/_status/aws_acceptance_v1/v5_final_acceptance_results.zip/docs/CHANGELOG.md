# Changelog

All notable changes to the Mini Issue Tracker project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-05-07

### Added
- Initial release of Mini Issue Tracker
- Issue model with validation (title, description, status, tags, timestamps)
- JSON storage with atomic writes using tempfile + os.replace
- Full CRUD operations (create, read, update, delete)
- Search functionality with filters:
  - Text search (case-insensitive, multi-term AND logic)
  - Tag filtering (must have ALL specified tags)
  - Status filtering (open/closed)
- Markdown report generation with grouping options:
  - Group by status
  - Group by tags
  - Chronological listing
- Complete CLI interface with 8 commands:
  - `create` - Create new issue
  - `list` - List issues with filtering and sorting
  - `show` - Show issue details
  - `update` - Update issue fields
  - `close` - Close an issue
  - `reopen` - Reopen a closed issue
  - `search` - Search issues
  - `report` - Generate markdown report
- Comprehensive test suite:
  - 80 tests covering all modules
  - Models: 100% coverage
  - Store: 95%+ coverage
  - Search: 90%+ coverage
  - CLI: 80%+ coverage
- Documentation:
  - README with quick start guide
  - DESIGN.md with architecture details
  - TEST_REPORT.md with test results
  - REVIEW.md with code review findings

### Technical Details
- Python 3.8+ compatible
- Zero external dependencies (stdlib only)
- Atomic writes prevent data corruption
- ISO 8601 timestamps
- UUID4 issue IDs
- Tag validation (lowercase, alphanumeric + hyphen/underscore)
- Proper error handling with exit codes

### Development Process
- Designed using planning subagent
- Implemented systematically (models → store → search → report → CLI)
- Tested comprehensively before release
- Reviewed by code review subagent
- All tests passing (80/80)

## [0.1.1] - 2026-05-07

### Security
- **CRITICAL FIX**: Added path validation to prevent path traversal attacks in JSONStore
  - Paths now restricted to user home directory or current working directory
  - Prevents arbitrary file system access
- Added output path validation for report generation
  - Validates output paths before writing files
  - Prevents writing to unauthorized locations

### Added
- Timestamp validation for ISO 8601 format
  - Validates created_at and updated_at timestamps
  - Ensures data integrity when loading from storage
- Type validation in Issue.from_dict()
  - Validates all field types before creating Issue instance
  - Prevents type-related runtime errors

### Changed
- Enhanced error messages for validation failures
- Improved security posture based on code review findings

### Testing
- All 80 tests passing after security enhancements
- No breaking changes to existing functionality

## [Unreleased]

### Planned Features
- Multi-user support with locking
- Issue comments and history
- Assignees and priorities
- Due dates and reminders
- Export to CSV/HTML
- Web interface
- Git integration
