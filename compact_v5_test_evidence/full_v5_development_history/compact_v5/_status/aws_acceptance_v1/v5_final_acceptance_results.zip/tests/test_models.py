"""Tests for issue models."""

import unittest
from datetime import datetime, timezone

from issue_tracker.models import Issue


class TestIssue(unittest.TestCase):
    """Test Issue model."""
    
    def test_create_minimal_issue(self):
        """Test creating issue with minimal required fields."""
        issue = Issue(title="Test issue")
        
        self.assertEqual(issue.title, "Test issue")
        self.assertEqual(issue.description, "")
        self.assertEqual(issue.status, "open")
        self.assertEqual(issue.tags, [])
        self.assertIsNotNone(issue.id)
        self.assertIsNotNone(issue.created_at)
        self.assertIsNotNone(issue.updated_at)
    
    def test_create_full_issue(self):
        """Test creating issue with all fields."""
        issue = Issue(
            title="Bug in login",
            description="Users cannot log in",
            status="open",
            tags=["bug", "auth"]
        )
        
        self.assertEqual(issue.title, "Bug in login")
        self.assertEqual(issue.description, "Users cannot log in")
        self.assertEqual(issue.status, "open")
        self.assertEqual(issue.tags, ["bug", "auth"])
    
    def test_title_validation_empty(self):
        """Test that empty title raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            Issue(title="")
        self.assertIn("empty", str(ctx.exception).lower())
    
    def test_title_validation_whitespace(self):
        """Test that whitespace-only title raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            Issue(title="   ")
        self.assertIn("empty", str(ctx.exception).lower())
    
    def test_title_validation_too_long(self):
        """Test that title exceeding max length raises ValueError."""
        long_title = "x" * 201
        with self.assertRaises(ValueError) as ctx:
            Issue(title=long_title)
        self.assertIn("200", str(ctx.exception))
    
    def test_title_strips_whitespace(self):
        """Test that title whitespace is stripped."""
        issue = Issue(title="  Test  ")
        self.assertEqual(issue.title, "Test")
    
    def test_description_validation_too_long(self):
        """Test that description exceeding max length raises ValueError."""
        long_desc = "x" * 10001
        with self.assertRaises(ValueError) as ctx:
            Issue(title="Test", description=long_desc)
        self.assertIn("10000", str(ctx.exception))
    
    def test_status_validation_invalid(self):
        """Test that invalid status raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            Issue(title="Test", status="invalid")
        self.assertIn("open", str(ctx.exception).lower())
    
    def test_status_case_insensitive(self):
        """Test that status is case-insensitive."""
        issue = Issue(title="Test", status="OPEN")
        self.assertEqual(issue.status, "open")
    
    def test_tags_validation_lowercase(self):
        """Test that tags are converted to lowercase."""
        issue = Issue(title="Test", tags=["Bug", "AUTH"])
        self.assertEqual(issue.tags, ["bug", "auth"])
    
    def test_tags_validation_duplicates(self):
        """Test that duplicate tags are removed."""
        issue = Issue(title="Test", tags=["bug", "bug", "auth"])
        self.assertEqual(issue.tags, ["bug", "auth"])
    
    def test_tags_validation_invalid_chars(self):
        """Test that tags with invalid characters raise ValueError."""
        with self.assertRaises(ValueError) as ctx:
            Issue(title="Test", tags=["bug!", "auth"])
        self.assertIn("invalid", str(ctx.exception).lower())
    
    def test_tags_validation_empty_strings(self):
        """Test that empty tag strings are filtered out."""
        issue = Issue(title="Test", tags=["bug", "", "auth"])
        self.assertEqual(issue.tags, ["bug", "auth"])
    
    def test_update_title(self):
        """Test updating issue title."""
        import time
        issue = Issue(title="Original")
        original_updated = issue.updated_at
        
        time.sleep(0.01)  # Ensure timestamp difference
        issue.update(title="Updated")
        
        self.assertEqual(issue.title, "Updated")
        self.assertNotEqual(issue.updated_at, original_updated)
    
    def test_update_description(self):
        """Test updating issue description."""
        issue = Issue(title="Test", description="Original")
        issue.update(description="Updated")
        self.assertEqual(issue.description, "Updated")
    
    def test_update_status(self):
        """Test updating issue status."""
        issue = Issue(title="Test")
        issue.update(status="closed")
        self.assertEqual(issue.status, "closed")
    
    def test_update_add_tags(self):
        """Test adding tags to issue."""
        issue = Issue(title="Test", tags=["bug"])
        issue.update(add_tags=["auth", "security"])
        self.assertEqual(set(issue.tags), {"bug", "auth", "security"})
    
    def test_update_remove_tags(self):
        """Test removing tags from issue."""
        issue = Issue(title="Test", tags=["bug", "auth", "security"])
        issue.update(remove_tags=["auth"])
        self.assertEqual(set(issue.tags), {"bug", "security"})
    
    def test_update_add_and_remove_tags(self):
        """Test adding and removing tags simultaneously."""
        issue = Issue(title="Test", tags=["bug", "old"])
        issue.update(add_tags=["new"], remove_tags=["old"])
        self.assertEqual(set(issue.tags), {"bug", "new"})
    
    def test_close(self):
        """Test closing an issue."""
        issue = Issue(title="Test")
        issue.close()
        self.assertEqual(issue.status, "closed")
    
    def test_reopen(self):
        """Test reopening an issue."""
        issue = Issue(title="Test", status="closed")
        issue.reopen()
        self.assertEqual(issue.status, "open")
    
    def test_to_dict(self):
        """Test serialization to dictionary."""
        issue = Issue(
            title="Test",
            description="Description",
            tags=["bug"]
        )
        
        data = issue.to_dict()
        
        self.assertEqual(data["title"], "Test")
        self.assertEqual(data["description"], "Description")
        self.assertEqual(data["status"], "open")
        self.assertEqual(data["tags"], ["bug"])
        self.assertIn("id", data)
        self.assertIn("created_at", data)
        self.assertIn("updated_at", data)
    
    def test_from_dict(self):
        """Test deserialization from dictionary."""
        data = {
            "id": "test-id",
            "title": "Test",
            "description": "Description",
            "status": "open",
            "tags": ["bug"],
            "created_at": "2026-05-01T10:00:00Z",
            "updated_at": "2026-05-01T10:00:00Z"
        }
        
        issue = Issue.from_dict(data)
        
        self.assertEqual(issue.id, "test-id")
        self.assertEqual(issue.title, "Test")
        self.assertEqual(issue.description, "Description")
        self.assertEqual(issue.status, "open")
        self.assertEqual(issue.tags, ["bug"])
    
    def test_from_dict_missing_field(self):
        """Test that from_dict raises ValueError for missing required fields."""
        data = {"title": "Test"}
        with self.assertRaises(ValueError) as ctx:
            Issue.from_dict(data)
        self.assertIn("required", str(ctx.exception).lower())
    
    def test_round_trip_serialization(self):
        """Test that to_dict/from_dict round-trip preserves data."""
        original = Issue(
            title="Test",
            description="Description",
            tags=["bug", "auth"]
        )
        
        data = original.to_dict()
        restored = Issue.from_dict(data)
        
        self.assertEqual(original.id, restored.id)
        self.assertEqual(original.title, restored.title)
        self.assertEqual(original.description, restored.description)
        self.assertEqual(original.status, restored.status)
        self.assertEqual(original.tags, restored.tags)
        self.assertEqual(original.created_at, restored.created_at)
        self.assertEqual(original.updated_at, restored.updated_at)


if __name__ == "__main__":
    unittest.main()
