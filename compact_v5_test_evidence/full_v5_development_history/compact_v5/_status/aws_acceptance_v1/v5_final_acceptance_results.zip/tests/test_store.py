"""Tests for JSON storage."""

import json
import os
import tempfile
import unittest
from pathlib import Path

from issue_tracker.store import JSONStore
from issue_tracker.models import Issue


class TestJSONStore(unittest.TestCase):
    """Test JSONStore."""
    
    def setUp(self):
        """Create temporary directory for test database."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_issues.json")
        self.store = JSONStore(self.db_path)
    
    def tearDown(self):
        """Clean up temporary files."""
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
        if os.path.exists(self.temp_dir):
            os.rmdir(self.temp_dir)
    
    def test_initialization_creates_file(self):
        """Test that initialization creates the database file."""
        self.assertTrue(os.path.exists(self.db_path))
    
    def test_initialization_creates_empty_dict(self):
        """Test that new database contains empty dict."""
        data = self.store.load()
        self.assertEqual(data, {})
    
    def test_add_issue(self):
        """Test adding an issue."""
        issue = Issue(title="Test issue")
        self.store.add(issue.to_dict())
        
        # Verify it was saved
        data = self.store.load()
        self.assertIn(issue.id, data)
        self.assertEqual(data[issue.id]["title"], "Test issue")
    
    def test_add_duplicate_id_raises_error(self):
        """Test that adding duplicate ID raises ValueError."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        
        with self.assertRaises(ValueError) as ctx:
            self.store.add(issue.to_dict())
        self.assertIn("already exists", str(ctx.exception))
    
    def test_add_without_id_raises_error(self):
        """Test that adding issue without ID raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            self.store.add({"title": "Test"})
        self.assertIn("id", str(ctx.exception).lower())
    
    def test_get_existing_issue(self):
        """Test getting an existing issue."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        
        retrieved = self.store.get(issue.id)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved["title"], "Test")
    
    def test_get_nonexistent_issue(self):
        """Test getting a nonexistent issue returns None."""
        retrieved = self.store.get("nonexistent-id")
        self.assertIsNone(retrieved)
    
    def test_list_all_empty(self):
        """Test listing all issues when store is empty."""
        issues = self.store.list_all()
        self.assertEqual(issues, [])
    
    def test_list_all_multiple(self):
        """Test listing all issues."""
        issue1 = Issue(title="Issue 1")
        issue2 = Issue(title="Issue 2")
        
        self.store.add(issue1.to_dict())
        self.store.add(issue2.to_dict())
        
        issues = self.store.list_all()
        self.assertEqual(len(issues), 2)
        titles = {issue["title"] for issue in issues}
        self.assertEqual(titles, {"Issue 1", "Issue 2"})
    
    def test_update_existing_issue(self):
        """Test updating an existing issue."""
        issue = Issue(title="Original")
        self.store.add(issue.to_dict())
        
        issue.update(title="Updated")
        self.store.update(issue.id, issue.to_dict())
        
        retrieved = self.store.get(issue.id)
        self.assertEqual(retrieved["title"], "Updated")
    
    def test_update_nonexistent_issue(self):
        """Test updating nonexistent issue raises ValueError."""
        issue = Issue(title="Test")
        with self.assertRaises(ValueError) as ctx:
            self.store.update("nonexistent-id", issue.to_dict())
        self.assertIn("not found", str(ctx.exception))
    
    def test_delete_existing_issue(self):
        """Test deleting an existing issue."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        
        self.store.delete(issue.id)
        
        retrieved = self.store.get(issue.id)
        self.assertIsNone(retrieved)
    
    def test_delete_nonexistent_issue(self):
        """Test deleting nonexistent issue raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            self.store.delete("nonexistent-id")
        self.assertIn("not found", str(ctx.exception))
    
    def test_exists_true(self):
        """Test exists returns True for existing issue."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        self.assertTrue(self.store.exists(issue.id))
    
    def test_exists_false(self):
        """Test exists returns False for nonexistent issue."""
        self.assertFalse(self.store.exists("nonexistent-id"))
    
    def test_atomic_write_creates_temp_file(self):
        """Test that atomic write uses temp file."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        
        # Check that no temp files remain
        temp_files = [f for f in os.listdir(self.temp_dir) if f.startswith(".issue_tracker_")]
        self.assertEqual(len(temp_files), 0)
    
    def test_multiple_rapid_writes(self):
        """Test multiple rapid writes (simulating concurrent access)."""
        for i in range(10):
            issue = Issue(title=f"Issue {i}")
            self.store.add(issue.to_dict())
        
        issues = self.store.list_all()
        self.assertEqual(len(issues), 10)
    
    def test_corrupted_json_handling(self):
        """Test handling of corrupted JSON file."""
        # Write invalid JSON
        with open(self.db_path, 'w') as f:
            f.write("invalid json {")
        
        with self.assertRaises(json.JSONDecodeError):
            self.store.load()
    
    def test_file_deleted_reinitializes(self):
        """Test that deleted file is reinitialized on load."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        
        # Delete the file
        os.unlink(self.db_path)
        
        # Load should reinitialize
        data = self.store.load()
        self.assertEqual(data, {})
        self.assertTrue(os.path.exists(self.db_path))
    
    def test_default_location(self):
        """Test that default location is used when no path provided."""
        store = JSONStore()
        expected_path = str(Path.home() / ".issue_tracker" / "issues.json")
        self.assertEqual(store.file_path, expected_path)


if __name__ == "__main__":
    unittest.main()
