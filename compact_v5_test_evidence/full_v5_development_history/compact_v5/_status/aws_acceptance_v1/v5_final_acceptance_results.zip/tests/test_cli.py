"""Tests for CLI functionality."""

import os
import sys
import tempfile
import unittest
from io import StringIO
from unittest.mock import patch

from issue_tracker.cli import (
    cmd_create,
    cmd_list,
    cmd_show,
    cmd_update,
    cmd_close,
    cmd_reopen,
    cmd_search,
    create_parser
)
from issue_tracker.store import JSONStore
from issue_tracker.models import Issue


class MockArgs:
    """Mock arguments object for testing."""
    def __init__(self, **kwargs):
        self.db_path = kwargs.get('db_path')
        for key, value in kwargs.items():
            setattr(self, key, value)


class TestCLI(unittest.TestCase):
    """Test CLI commands."""
    
    def setUp(self):
        """Create temporary database for testing."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_issues.json")
        self.store = JSONStore(self.db_path)
    
    def tearDown(self):
        """Clean up temporary files."""
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
        if os.path.exists(self.temp_dir):
            os.rmdir(self.temp_dir)
    
    def test_cmd_create_minimal(self):
        """Test creating issue with minimal arguments."""
        args = MockArgs(
            db_path=self.db_path,
            title="Test issue",
            description=None,
            tags=None
        )
        
        with patch('sys.stdout', new=StringIO()) as fake_out:
            exit_code = cmd_create(args)
        
        self.assertEqual(exit_code, 0)
        issues = self.store.list_all()
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["title"], "Test issue")
    
    def test_cmd_create_with_tags(self):
        """Test creating issue with tags."""
        args = MockArgs(
            db_path=self.db_path,
            title="Test issue",
            description="Description",
            tags="bug,auth"
        )
        
        exit_code = cmd_create(args)
        
        self.assertEqual(exit_code, 0)
        issues = self.store.list_all()
        self.assertEqual(set(issues[0]["tags"]), {"bug", "auth"})
    
    def test_cmd_create_invalid_title(self):
        """Test creating issue with invalid title."""
        args = MockArgs(
            db_path=self.db_path,
            title="",
            description=None,
            tags=None
        )
        
        with patch('sys.stderr', new=StringIO()):
            exit_code = cmd_create(args)
        
        self.assertEqual(exit_code, 1)
    
    def test_cmd_list_empty(self):
        """Test listing when no issues exist."""
        args = MockArgs(
            db_path=self.db_path,
            status="all",
            tags=None,
            sort="created",
            reverse=False
        )
        
        with patch('sys.stdout', new=StringIO()) as fake_out:
            exit_code = cmd_list(args)
            output = fake_out.getvalue()
        
        self.assertEqual(exit_code, 0)
        self.assertIn("No issues", output)
    
    def test_cmd_list_with_issues(self):
        """Test listing issues."""
        issue = Issue(title="Test issue")
        self.store.add(issue.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            status="all",
            tags=None,
            sort="created",
            reverse=False
        )
        
        with patch('sys.stdout', new=StringIO()) as fake_out:
            exit_code = cmd_list(args)
            output = fake_out.getvalue()
        
        self.assertEqual(exit_code, 0)
        self.assertIn("Test issue", output)
    
    def test_cmd_list_filter_by_status(self):
        """Test listing with status filter."""
        issue1 = Issue(title="Open issue")
        issue2 = Issue(title="Closed issue", status="closed")
        self.store.add(issue1.to_dict())
        self.store.add(issue2.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            status="open",
            tags=None,
            sort="created",
            reverse=False
        )
        
        with patch('sys.stdout', new=StringIO()) as fake_out:
            exit_code = cmd_list(args)
            output = fake_out.getvalue()
        
        self.assertEqual(exit_code, 0)
        self.assertIn("Open issue", output)
        self.assertNotIn("Closed issue", output)
    
    def test_cmd_show_existing(self):
        """Test showing an existing issue."""
        issue = Issue(title="Test issue", description="Test description")
        self.store.add(issue.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            id=issue.id
        )
        
        with patch('sys.stdout', new=StringIO()) as fake_out:
            exit_code = cmd_show(args)
            output = fake_out.getvalue()
        
        self.assertEqual(exit_code, 0)
        self.assertIn("Test issue", output)
        self.assertIn("Test description", output)
    
    def test_cmd_show_nonexistent(self):
        """Test showing nonexistent issue."""
        args = MockArgs(
            db_path=self.db_path,
            id="nonexistent-id"
        )
        
        with patch('sys.stderr', new=StringIO()) as fake_err:
            exit_code = cmd_show(args)
            output = fake_err.getvalue()
        
        self.assertEqual(exit_code, 1)
        self.assertIn("not found", output)
    
    def test_cmd_update_title(self):
        """Test updating issue title."""
        issue = Issue(title="Original")
        self.store.add(issue.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            id=issue.id,
            title="Updated",
            description=None,
            add_tags=None,
            remove_tags=None
        )
        
        exit_code = cmd_update(args)
        
        self.assertEqual(exit_code, 0)
        updated = self.store.get(issue.id)
        self.assertEqual(updated["title"], "Updated")
    
    def test_cmd_update_add_tags(self):
        """Test adding tags via update."""
        issue = Issue(title="Test", tags=["bug"])
        self.store.add(issue.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            id=issue.id,
            title=None,
            description=None,
            add_tags="auth,security",
            remove_tags=None
        )
        
        exit_code = cmd_update(args)
        
        self.assertEqual(exit_code, 0)
        updated = self.store.get(issue.id)
        self.assertIn("auth", updated["tags"])
        self.assertIn("security", updated["tags"])
    
    def test_cmd_close(self):
        """Test closing an issue."""
        issue = Issue(title="Test")
        self.store.add(issue.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            id=issue.id
        )
        
        exit_code = cmd_close(args)
        
        self.assertEqual(exit_code, 0)
        updated = self.store.get(issue.id)
        self.assertEqual(updated["status"], "closed")
    
    def test_cmd_reopen(self):
        """Test reopening an issue."""
        issue = Issue(title="Test", status="closed")
        self.store.add(issue.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            id=issue.id
        )
        
        exit_code = cmd_reopen(args)
        
        self.assertEqual(exit_code, 0)
        updated = self.store.get(issue.id)
        self.assertEqual(updated["status"], "open")
    
    def test_cmd_search_by_query(self):
        """Test searching by text query."""
        issue1 = Issue(title="Bug in login")
        issue2 = Issue(title="Feature request")
        self.store.add(issue1.to_dict())
        self.store.add(issue2.to_dict())
        
        args = MockArgs(
            db_path=self.db_path,
            query="login",
            tags=None,
            status="all"
        )
        
        with patch('sys.stdout', new=StringIO()) as fake_out:
            exit_code = cmd_search(args)
            output = fake_out.getvalue()
        
        self.assertEqual(exit_code, 0)
        self.assertIn("Bug in login", output)
        self.assertNotIn("Feature request", output)
    
    def test_parser_create_command(self):
        """Test parser for create command."""
        parser = create_parser()
        args = parser.parse_args(["create", "--title", "Test"])
        self.assertEqual(args.command, "create")
        self.assertEqual(args.title, "Test")
    
    def test_parser_list_command(self):
        """Test parser for list command."""
        parser = create_parser()
        args = parser.parse_args(["list", "--status", "open"])
        self.assertEqual(args.command, "list")
        self.assertEqual(args.status, "open")
    
    def test_parser_show_command(self):
        """Test parser for show command."""
        parser = create_parser()
        args = parser.parse_args(["show", "test-id"])
        self.assertEqual(args.command, "show")
        self.assertEqual(args.id, "test-id")


if __name__ == "__main__":
    unittest.main()
