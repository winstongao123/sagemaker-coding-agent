"""Tests for search functionality."""

import os
import tempfile
import unittest

from issue_tracker.models import Issue
from issue_tracker.store import JSONStore
from issue_tracker.search import (
    search_issues,
    filter_by_status,
    filter_by_tags,
    filter_by_text,
    sort_issues
)


class TestSearch(unittest.TestCase):
    """Test search functionality."""
    
    def setUp(self):
        """Create temporary store with test data."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_issues.json")
        self.store = JSONStore(self.db_path)
        
        # Create test issues
        self.issue1 = Issue(title="Bug in login", description="Users cannot log in", tags=["bug", "auth"])
        self.issue2 = Issue(title="Feature request", description="Add dark mode", tags=["feature"])
        self.issue3 = Issue(title="Bug in logout", description="Logout fails", tags=["bug", "auth"], status="closed")
        
        self.store.add(self.issue1.to_dict())
        self.store.add(self.issue2.to_dict())
        self.store.add(self.issue3.to_dict())
    
    def tearDown(self):
        """Clean up temporary files."""
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
        if os.path.exists(self.temp_dir):
            os.rmdir(self.temp_dir)
    
    def test_filter_by_status_open(self):
        """Test filtering by open status."""
        issues = self.store.list_all()
        filtered = filter_by_status(issues, "open")
        self.assertEqual(len(filtered), 2)
        for issue in filtered:
            self.assertEqual(issue["status"], "open")
    
    def test_filter_by_status_closed(self):
        """Test filtering by closed status."""
        issues = self.store.list_all()
        filtered = filter_by_status(issues, "closed")
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0]["status"], "closed")
    
    def test_filter_by_tags_single(self):
        """Test filtering by single tag."""
        issues = self.store.list_all()
        filtered = filter_by_tags(issues, ["bug"])
        self.assertEqual(len(filtered), 2)
        for issue in filtered:
            self.assertIn("bug", issue["tags"])
    
    def test_filter_by_tags_multiple(self):
        """Test filtering by multiple tags (AND logic)."""
        issues = self.store.list_all()
        filtered = filter_by_tags(issues, ["bug", "auth"])
        self.assertEqual(len(filtered), 2)
        for issue in filtered:
            self.assertIn("bug", issue["tags"])
            self.assertIn("auth", issue["tags"])
    
    def test_filter_by_tags_no_match(self):
        """Test filtering by tags with no matches."""
        issues = self.store.list_all()
        filtered = filter_by_tags(issues, ["nonexistent"])
        self.assertEqual(len(filtered), 0)
    
    def test_filter_by_text_single_term(self):
        """Test text search with single term."""
        issues = self.store.list_all()
        filtered = filter_by_text(issues, "login")
        self.assertEqual(len(filtered), 1)
        self.assertIn("login", filtered[0]["title"].lower())
    
    def test_filter_by_text_multiple_terms(self):
        """Test text search with multiple terms (AND logic)."""
        issues = self.store.list_all()
        filtered = filter_by_text(issues, "bug login")
        self.assertEqual(len(filtered), 1)
        self.assertIn("login", filtered[0]["title"].lower())
    
    def test_filter_by_text_case_insensitive(self):
        """Test that text search is case-insensitive."""
        issues = self.store.list_all()
        filtered = filter_by_text(issues, "BUG")
        self.assertEqual(len(filtered), 2)
    
    def test_filter_by_text_searches_description(self):
        """Test that text search includes description."""
        issues = self.store.list_all()
        filtered = filter_by_text(issues, "dark mode")
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0]["title"], "Feature request")
    
    def test_filter_by_text_no_match(self):
        """Test text search with no matches."""
        issues = self.store.list_all()
        filtered = filter_by_text(issues, "nonexistent")
        self.assertEqual(len(filtered), 0)
    
    def test_search_issues_no_filters(self):
        """Test search with no filters returns all issues."""
        results = search_issues(self.store)
        self.assertEqual(len(results), 3)
    
    def test_search_issues_status_filter(self):
        """Test search with status filter."""
        results = search_issues(self.store, status="open")
        self.assertEqual(len(results), 2)
    
    def test_search_issues_tag_filter(self):
        """Test search with tag filter."""
        results = search_issues(self.store, tags=["feature"])
        self.assertEqual(len(results), 1)
    
    def test_search_issues_text_query(self):
        """Test search with text query."""
        results = search_issues(self.store, query="logout")
        self.assertEqual(len(results), 1)
    
    def test_search_issues_combined_filters(self):
        """Test search with multiple filters."""
        results = search_issues(self.store, query="bug", tags=["auth"], status="open")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["title"], "Bug in login")
    
    def test_sort_issues_by_created(self):
        """Test sorting by created date."""
        issues = self.store.list_all()
        sorted_issues = sort_issues(issues, sort_by="created")
        # Should be in chronological order
        self.assertEqual(len(sorted_issues), 3)
    
    def test_sort_issues_by_title(self):
        """Test sorting by title."""
        issues = self.store.list_all()
        sorted_issues = sort_issues(issues, sort_by="title")
        titles = [issue["title"] for issue in sorted_issues]
        self.assertEqual(titles, sorted(titles))
    
    def test_sort_issues_reverse(self):
        """Test reverse sorting."""
        issues = self.store.list_all()
        sorted_issues = sort_issues(issues, sort_by="title", reverse=True)
        titles = [issue["title"] for issue in sorted_issues]
        self.assertEqual(titles, sorted(titles, reverse=True))
    
    def test_sort_issues_invalid_field(self):
        """Test that invalid sort field raises ValueError."""
        issues = self.store.list_all()
        with self.assertRaises(ValueError):
            sort_issues(issues, sort_by="invalid")


if __name__ == "__main__":
    unittest.main()
