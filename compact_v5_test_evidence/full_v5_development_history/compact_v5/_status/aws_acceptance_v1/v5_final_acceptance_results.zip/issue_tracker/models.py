"""Issue model with validation and serialization."""

import re
import uuid
from datetime import datetime, timezone
from typing import Optional


class Issue:
    """Represents a single issue with validation."""
    
    VALID_STATUSES = {"open", "closed"}
    MAX_TITLE_LENGTH = 200
    MAX_DESCRIPTION_LENGTH = 10000
    TAG_PATTERN = re.compile(r'^[a-z0-9_-]+$')
    
    def __init__(
        self,
        title: str,
        description: str = "",
        status: str = "open",
        tags: Optional[list[str]] = None,
        issue_id: Optional[str] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None
    ):
        """Initialize an issue with validation.
        
        Args:
            title: Issue title (required, 1-200 chars)
            description: Issue description (optional, max 10000 chars)
            status: Issue status ("open" or "closed")
            tags: List of tags (lowercase, alphanumeric + hyphen/underscore)
            issue_id: UUID (auto-generated if not provided)
            created_at: ISO 8601 timestamp (auto-generated if not provided)
            updated_at: ISO 8601 timestamp (auto-generated if not provided)
        
        Raises:
            ValueError: If validation fails
        """
        self.id = issue_id or str(uuid.uuid4())
        self.title = self._validate_title(title)
        self.description = self._validate_description(description)
        self.status = self._validate_status(status)
        self.tags = self._validate_tags(tags or [])
        
        now = datetime.now(timezone.utc).isoformat()
        self.created_at = self._validate_timestamp(created_at) if created_at else now
        self.updated_at = self._validate_timestamp(updated_at) if updated_at else now
    
    def _validate_title(self, title: str) -> str:
        """Validate and normalize title."""
        if not isinstance(title, str):
            raise ValueError("Title must be a string")
        
        title = title.strip()
        if not title:
            raise ValueError("Title cannot be empty")
        
        if len(title) > self.MAX_TITLE_LENGTH:
            raise ValueError(f"Title cannot exceed {self.MAX_TITLE_LENGTH} characters")
        
        return title
    
    def _validate_description(self, description: str) -> str:
        """Validate description."""
        if not isinstance(description, str):
            raise ValueError("Description must be a string")
        
        if len(description) > self.MAX_DESCRIPTION_LENGTH:
            raise ValueError(f"Description cannot exceed {self.MAX_DESCRIPTION_LENGTH} characters")
        
        return description
    
    def _validate_status(self, status: str) -> str:
        """Validate status."""
        if not isinstance(status, str):
            raise ValueError("Status must be a string")
        
        status = status.lower()
        if status not in self.VALID_STATUSES:
            raise ValueError(f"Status must be one of: {', '.join(self.VALID_STATUSES)}")
        
        return status
    
    def _validate_tags(self, tags: list[str]) -> list[str]:
        """Validate and normalize tags."""
        if not isinstance(tags, list):
            raise ValueError("Tags must be a list")
        
        validated = []
        seen = set()
        
        for tag in tags:
            if not isinstance(tag, str):
                raise ValueError("Each tag must be a string")
            
            tag = tag.lower().strip()
            if not tag:
                continue
            
            if not self.TAG_PATTERN.match(tag):
                raise ValueError(
                    f"Tag '{tag}' is invalid. Tags must contain only lowercase letters, "
                    "numbers, hyphens, and underscores"
                )
            
            if tag not in seen:
                validated.append(tag)
                seen.add(tag)
        
        return validated
    
    def _validate_timestamp(self, timestamp: str) -> str:
        """Validate ISO 8601 timestamp format.
        
        Args:
            timestamp: Timestamp string to validate
        
        Returns:
            Validated timestamp string
        
        Raises:
            ValueError: If timestamp is invalid
        """
        if not isinstance(timestamp, str):
            raise ValueError("Timestamp must be a string")
        
        try:
            # Attempt to parse as ISO 8601
            datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            return timestamp
        except (ValueError, AttributeError) as e:
            raise ValueError(f"Invalid timestamp format (expected ISO 8601): {e}")
    
    def update(
        self,
        title: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
        add_tags: Optional[list[str]] = None,
        remove_tags: Optional[list[str]] = None
    ) -> None:
        """Update issue fields.
        
        Args:
            title: New title (optional)
            description: New description (optional)
            status: New status (optional)
            add_tags: Tags to add (optional)
            remove_tags: Tags to remove (optional)
        
        Raises:
            ValueError: If validation fails
        """
        if title is not None:
            self.title = self._validate_title(title)
        
        if description is not None:
            self.description = self._validate_description(description)
        
        if status is not None:
            self.status = self._validate_status(status)
        
        if remove_tags:
            remove_set = set(tag.lower() for tag in remove_tags)
            self.tags = [tag for tag in self.tags if tag not in remove_set]
        
        if add_tags:
            # Combine existing and new tags, then validate
            combined = self.tags + add_tags
            self.tags = self._validate_tags(combined)
        
        # Update timestamp
        self.updated_at = datetime.now(timezone.utc).isoformat()
    
    def close(self) -> None:
        """Close the issue."""
        self.update(status="closed")
    
    def reopen(self) -> None:
        """Reopen the issue."""
        self.update(status="open")
    
    def to_dict(self) -> dict:
        """Convert issue to dictionary for serialization."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Issue":
        """Create issue from dictionary.
        
        Args:
            data: Dictionary with issue data
        
        Returns:
            Issue instance
        
        Raises:
            ValueError: If required fields are missing or invalid
            TypeError: If field types are incorrect
        """
        if not isinstance(data, dict):
            raise TypeError("Data must be a dictionary")
        
        required_fields = ["id", "title", "status", "created_at", "updated_at"]
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")
        
        # Validate types
        if not isinstance(data["id"], str):
            raise TypeError("Field 'id' must be a string")
        if not isinstance(data["title"], str):
            raise TypeError("Field 'title' must be a string")
        if not isinstance(data["status"], str):
            raise TypeError("Field 'status' must be a string")
        if not isinstance(data["created_at"], str):
            raise TypeError("Field 'created_at' must be a string")
        if not isinstance(data["updated_at"], str):
            raise TypeError("Field 'updated_at' must be a string")
        
        description = data.get("description", "")
        if not isinstance(description, str):
            raise TypeError("Field 'description' must be a string")
        
        tags = data.get("tags", [])
        if not isinstance(tags, list):
            raise TypeError("Field 'tags' must be a list")
        
        return cls(
            title=data["title"],
            description=description,
            status=data["status"],
            tags=tags,
            issue_id=data["id"],
            created_at=data["created_at"],
            updated_at=data["updated_at"]
        )
    
    def __repr__(self) -> str:
        """String representation of issue."""
        return f"Issue(id={self.id[:8]}..., title={self.title!r}, status={self.status})"
