"""JSON storage with atomic writes."""

import json
import os
import tempfile
from pathlib import Path
from typing import Optional


class JSONStore:
    """Persistent JSON storage with atomic write guarantees."""
    
    def __init__(self, file_path: Optional[str] = None):
        """Initialize store with file path.
        
        Args:
            file_path: Path to JSON file. If None, uses default location.
        
        Raises:
            ValueError: If path is invalid or outside allowed directories
        """
        if file_path is None:
            # Default location: ~/.issue_tracker/issues.json
            home = Path.home()
            default_dir = home / ".issue_tracker"
            default_dir.mkdir(exist_ok=True)
            file_path = str(default_dir / "issues.json")
        
        # Validate path is within user home directory or current working directory
        self._validate_path(file_path)
        self.file_path = file_path
        
        # Initialize file if it doesn't exist
        if not os.path.exists(self.file_path):
            self._initialize_file()
    
    def _validate_path(self, file_path: str) -> None:
        """Validate that file path is safe.
        
        Args:
            file_path: Path to validate
        
        Raises:
            ValueError: If path is invalid or outside allowed directories
        """
        try:
            resolved = Path(file_path).resolve()
            home = Path.home().resolve()
            cwd = Path.cwd().resolve()
            
            # Allow paths within home directory or current working directory
            if not (str(resolved).startswith(str(home)) or str(resolved).startswith(str(cwd))):
                raise ValueError(
                    f"Path must be within home directory ({home}) or current directory ({cwd})"
                )
        except (OSError, RuntimeError) as e:
            raise ValueError(f"Invalid file path: {e}")
    
    def _initialize_file(self) -> None:
        """Create empty storage file."""
        os.makedirs(os.path.dirname(self.file_path) or ".", exist_ok=True)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump({}, f)
    
    def load(self) -> dict[str, dict]:
        """Load all issues from storage.
        
        Returns:
            Dictionary mapping issue IDs to issue data
        
        Raises:
            json.JSONDecodeError: If file contains invalid JSON
            OSError: If file cannot be read
        """
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if not isinstance(data, dict):
                    raise ValueError("Storage file must contain a JSON object")
                return data
        except FileNotFoundError:
            # File was deleted, reinitialize
            self._initialize_file()
            return {}
    
    def save(self, data: dict[str, dict]) -> None:
        """Atomically write data to storage.
        
        Uses tempfile + os.replace for atomic write operation.
        
        Args:
            data: Dictionary mapping issue IDs to issue data
        
        Raises:
            OSError: If write fails
            TypeError: If data is not JSON-serializable
        """
        # Serialize first (fail early if not serializable)
        json_str = json.dumps(data, indent=2, ensure_ascii=False)
        
        # Create temp file in same directory (same filesystem)
        dir_path = os.path.dirname(self.file_path) or "."
        
        # Use delete=False to manually control cleanup
        with tempfile.NamedTemporaryFile(
            mode='w',
            encoding='utf-8',
            dir=dir_path,
            delete=False,
            suffix='.tmp',
            prefix='.issue_tracker_'
        ) as tmp_file:
            tmp_path = tmp_file.name
            
            try:
                # Write data
                tmp_file.write(json_str)
                tmp_file.flush()
                os.fsync(tmp_file.fileno())  # Force write to disk
                
                # Close before rename (Windows requirement)
                tmp_file.close()
                
                # Atomic replace (POSIX and Windows 3.3+)
                os.replace(tmp_path, self.file_path)
                
            except Exception:
                # Clean up temp file on error
                try:
                    if os.path.exists(tmp_path):
                        os.unlink(tmp_path)
                except OSError:
                    pass
                raise
    
    def get(self, issue_id: str) -> Optional[dict]:
        """Get a single issue by ID.
        
        Args:
            issue_id: Issue ID
        
        Returns:
            Issue data dictionary or None if not found
        """
        data = self.load()
        return data.get(issue_id)
    
    def list_all(self) -> list[dict]:
        """Get all issues as a list.
        
        Returns:
            List of issue data dictionaries
        """
        data = self.load()
        return list(data.values())
    
    def add(self, issue_dict: dict) -> None:
        """Add a new issue.
        
        Args:
            issue_dict: Issue data dictionary (must include 'id' field)
        
        Raises:
            ValueError: If issue ID already exists or 'id' field is missing
            OSError: If write fails
        """
        if "id" not in issue_dict:
            raise ValueError("Issue dictionary must include 'id' field")
        
        issue_id = issue_dict["id"]
        data = self.load()
        
        if issue_id in data:
            raise ValueError(f"Issue with ID {issue_id} already exists")
        
        data[issue_id] = issue_dict
        self.save(data)
    
    def update(self, issue_id: str, issue_dict: dict) -> None:
        """Update an existing issue.
        
        Args:
            issue_id: Issue ID
            issue_dict: Updated issue data dictionary
        
        Raises:
            ValueError: If issue ID not found
            OSError: If write fails
        """
        data = self.load()
        
        if issue_id not in data:
            raise ValueError(f"Issue with ID {issue_id} not found")
        
        data[issue_id] = issue_dict
        self.save(data)
    
    def delete(self, issue_id: str) -> None:
        """Delete an issue.
        
        Args:
            issue_id: Issue ID
        
        Raises:
            ValueError: If issue ID not found
            OSError: If write fails
        """
        data = self.load()
        
        if issue_id not in data:
            raise ValueError(f"Issue with ID {issue_id} not found")
        
        del data[issue_id]
        self.save(data)
    
    def exists(self, issue_id: str) -> bool:
        """Check if an issue exists.
        
        Args:
            issue_id: Issue ID
        
        Returns:
            True if issue exists, False otherwise
        """
        data = self.load()
        return issue_id in data
