"""Markdown report generation for issues."""

from datetime import datetime
from typing import Optional


def generate_report(
    issues: list[dict],
    group_by: str = "status",
    title: str = "Issue Tracker Report"
) -> str:
    """Generate a markdown report from issues.
    
    Args:
        issues: List of issue dictionaries
        group_by: Grouping strategy ("status", "tags", or "none")
        title: Report title
    
    Returns:
        Markdown-formatted report string
    """
    lines = []
    
    # Header
    lines.append(f"# {title}")
    lines.append("")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    
    # Summary
    summary = generate_summary(issues)
    lines.append(summary)
    lines.append("")
    
    # Issues grouped by strategy
    if group_by == "status":
        lines.extend(group_by_status(issues))
    elif group_by == "tags":
        lines.extend(group_by_tags(issues))
    elif group_by == "none":
        lines.extend(list_all_issues(issues))
    else:
        raise ValueError(f"Invalid group_by value: {group_by}")
    
    return "\n".join(lines)


def generate_summary(issues: list[dict]) -> str:
    """Generate summary statistics.
    
    Args:
        issues: List of issue dictionaries
    
    Returns:
        Markdown-formatted summary
    """
    total = len(issues)
    open_count = sum(1 for issue in issues if issue.get("status") == "open")
    closed_count = total - open_count
    
    lines = [
        "## Summary",
        "",
        f"- **Total Issues**: {total}",
        f"- **Open**: {open_count}",
        f"- **Closed**: {closed_count}",
    ]
    
    return "\n".join(lines)


def group_by_status(issues: list[dict]) -> list[str]:
    """Group issues by status.
    
    Args:
        issues: List of issue dictionaries
    
    Returns:
        List of markdown lines
    """
    lines = ["## Issues by Status", ""]
    
    # Separate by status
    open_issues = [i for i in issues if i.get("status") == "open"]
    closed_issues = [i for i in issues if i.get("status") == "closed"]
    
    # Open issues first
    if open_issues:
        lines.append(f"### Open Issues ({len(open_issues)})")
        lines.append("")
        for issue in sorted(open_issues, key=lambda x: x.get("created_at", ""), reverse=True):
            lines.extend(format_issue_section(issue))
            lines.append("")
    
    # Closed issues
    if closed_issues:
        lines.append(f"### Closed Issues ({len(closed_issues)})")
        lines.append("")
        for issue in sorted(closed_issues, key=lambda x: x.get("updated_at", ""), reverse=True):
            lines.extend(format_issue_section(issue))
            lines.append("")
    
    return lines


def group_by_tags(issues: list[dict]) -> list[str]:
    """Group issues by primary tag.
    
    Args:
        issues: List of issue dictionaries
    
    Returns:
        List of markdown lines
    """
    lines = ["## Issues by Tag", ""]
    
    # Group by first tag
    tag_groups = {}
    untagged = []
    
    for issue in issues:
        tags = issue.get("tags", [])
        if tags:
            primary_tag = tags[0]
            if primary_tag not in tag_groups:
                tag_groups[primary_tag] = []
            tag_groups[primary_tag].append(issue)
        else:
            untagged.append(issue)
    
    # Sort tags alphabetically
    for tag in sorted(tag_groups.keys()):
        tag_issues = tag_groups[tag]
        lines.append(f"### Tag: {tag} ({len(tag_issues)})")
        lines.append("")
        for issue in sorted(tag_issues, key=lambda x: x.get("created_at", ""), reverse=True):
            lines.extend(format_issue_section(issue))
            lines.append("")
    
    # Untagged issues
    if untagged:
        lines.append(f"### Untagged ({len(untagged)})")
        lines.append("")
        for issue in sorted(untagged, key=lambda x: x.get("created_at", ""), reverse=True):
            lines.extend(format_issue_section(issue))
            lines.append("")
    
    return lines


def list_all_issues(issues: list[dict]) -> list[str]:
    """List all issues chronologically.
    
    Args:
        issues: List of issue dictionaries
    
    Returns:
        List of markdown lines
    """
    lines = ["## All Issues", ""]
    
    # Sort by created date, newest first
    sorted_issues = sorted(issues, key=lambda x: x.get("created_at", ""), reverse=True)
    
    for issue in sorted_issues:
        lines.extend(format_issue_section(issue))
        lines.append("")
    
    return lines


def format_issue_section(issue: dict) -> list[str]:
    """Format a single issue as markdown.
    
    Args:
        issue: Issue dictionary
    
    Returns:
        List of markdown lines
    """
    lines = []
    
    # Title with ID
    issue_id = issue.get("id", "unknown")
    title = issue.get("title", "Untitled")
    lines.append(f"#### [{issue_id[:8]}] {title}")
    lines.append("")
    
    # Metadata
    status = issue.get("status", "unknown")
    created = format_timestamp(issue.get("created_at", ""))
    updated = format_timestamp(issue.get("updated_at", ""))
    tags = issue.get("tags", [])
    
    lines.append(f"**Status**: {status}")
    lines.append(f"**Created**: {created}")
    lines.append(f"**Updated**: {updated}")
    
    if tags:
        tags_str = ", ".join(tags)
        lines.append(f"**Tags**: {tags_str}")
    
    lines.append("")
    
    # Description
    description = issue.get("description", "")
    if description:
        lines.append(description)
    else:
        lines.append("*No description provided*")
    
    lines.append("")
    lines.append("---")
    
    return lines


def format_timestamp(timestamp: str) -> str:
    """Format ISO 8601 timestamp for display.
    
    Args:
        timestamp: ISO 8601 timestamp string
    
    Returns:
        Formatted timestamp string
    """
    if not timestamp:
        return "Unknown"
    
    try:
        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, AttributeError):
        return timestamp
