"""Mini Issue Tracker - A lightweight issue tracking system."""

__version__ = "0.1.0"

from .models import Issue
from .store import JSONStore

__all__ = ["Issue", "JSONStore"]
