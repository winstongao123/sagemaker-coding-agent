"""Search and filter functionality for issues."""

from typing import Optional


def search_issues(
    store,
    query: Optional[str] = None,
    tags: Optional[list[str]] = None,
    status: Optional[str] = None
) -> list[dict]:
    """Search issues with multiple filters.
    
    Args:
        store: JSONStore instance
        query: Text search query (searches title and description)
        tags: List of tags (issue must have ALL specified tags)
        status: Status filter ("open", "closed", or None for all)
    
    Returns:
        List of matching issue dictionaries
    """
    issues = store.list_all()
    
    # Apply status filter
    if status and status != "all":
        issues = filter_by_status(issues, status)
    
    # Apply tag filter
    if tags:
        issues = filter_by_tags(issues, tags)
    
    # Apply text search
    if query:
        issues = filter_by_text(issues, query)
    
    return issues


def filter_by_status(issues: list[dict], status: str) -> list[dict]:
    """Filter issues by status.
    
    Args:
        issues: List of issue dictionaries
        status: Status to filter by ("open" or "closed")
    
    Returns:
        Filtered list of issues
    """
    status = status.lower()
    return [issue for issue in issues if issue.get("status") == status]


def filter_by_tags(issues: list[dict], required_tags: list[str]) -> list[dict]:
    """Filter issues that have ALL required tags.
    
    Args:
        issues: List of issue dictionaries
        required_tags: List of tags (issue must have all of them)
    
    Returns:
        Filtered list of issues
    """
    required_set = set(tag.lower() for tag in required_tags)
    return [
        issue for issue in issues
        if required_set.issubset(set(issue.get("tags", [])))
    ]


def filter_by_text(issues: list[dict], query: str) -> list[dict]:
    """Filter issues by text search (case-insensitive).
    
    Searches in title and description. All query terms must match (AND logic).
    
    Args:
        issues: List of issue dictionaries
        query: Search query (space-separated terms)
    
    Returns:
        Filtered list of issues
    """
    terms = query.lower().split()
    results = []
    
    for issue in issues:
        searchable = (
            issue.get("title", "") + " " + 
            issue.get("description", "")
        ).lower()
        
        if all(term in searchable for term in terms):
            results.append(issue)
    
    return results


def sort_issues(
    issues: list[dict],
    sort_by: str = "created",
    reverse: bool = False
) -> list[dict]:
    """Sort issues by specified field.
    
    Args:
        issues: List of issue dictionaries
        sort_by: Field to sort by ("created", "updated", or "title")
        reverse: If True, sort in descending order
    
    Returns:
        Sorted list of issues
    """
    if sort_by == "created":
        key_func = lambda x: x.get("created_at", "")
    elif sort_by == "updated":
        key_func = lambda x: x.get("updated_at", "")
    elif sort_by == "title":
        key_func = lambda x: x.get("title", "").lower()
    else:
        raise ValueError(f"Invalid sort field: {sort_by}")
    
    return sorted(issues, key=key_func, reverse=reverse)
