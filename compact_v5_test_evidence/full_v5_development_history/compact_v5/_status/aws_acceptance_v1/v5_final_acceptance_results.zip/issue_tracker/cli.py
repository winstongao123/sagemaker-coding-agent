"""Command-line interface for issue tracker."""

import argparse
import os
import sys
from typing import Optional

from .models import Issue
from .store import JSONStore
from .search import search_issues, sort_issues
from .report import generate_report


def get_store(db_path: Optional[str] = None) -> JSONStore:
    """Get JSONStore instance with optional custom path.
    
    Args:
        db_path: Optional custom database path
    
    Returns:
        JSONStore instance
    """
    if db_path is None:
        db_path = os.environ.get("ISSUE_TRACKER_DB")
    return JSONStore(db_path)


def cmd_create(args) -> int:
    """Create a new issue.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        
        # Parse tags
        tags = []
        if args.tags:
            tags = [tag.strip() for tag in args.tags.split(",")]
        
        # Create issue
        issue = Issue(
            title=args.title,
            description=args.description or "",
            tags=tags
        )
        
        # Save to store
        store.add(issue.to_dict())
        
        print(f"Created issue: {issue.id}")
        print(f"Title: {issue.title}")
        if tags:
            print(f"Tags: {', '.join(tags)}")
        
        return 0
        
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except OSError as e:
        print(f"Storage error: {e}", file=sys.stderr)
        return 2


def cmd_list(args) -> int:
    """List issues with optional filtering and sorting.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        
        # Parse tags
        tags = None
        if args.tags:
            tags = [tag.strip() for tag in args.tags.split(",")]
        
        # Search with filters
        status = args.status if args.status != "all" else None
        issues = search_issues(store, tags=tags, status=status)
        
        # Sort
        issues = sort_issues(issues, sort_by=args.sort, reverse=args.reverse)
        
        if not issues:
            print("No issues found.")
            return 0
        
        # Display
        print(f"Found {len(issues)} issue(s):\n")
        for issue in issues:
            print_issue_summary(issue)
            print()
        
        return 0
        
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_show(args) -> int:
    """Show detailed information about an issue.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        issue_dict = store.get(args.id)
        
        if issue_dict is None:
            print(f"Error: Issue {args.id} not found", file=sys.stderr)
            return 1
        
        print_issue_detail(issue_dict)
        return 0
        
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_update(args) -> int:
    """Update an existing issue.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        issue_dict = store.get(args.id)
        
        if issue_dict is None:
            print(f"Error: Issue {args.id} not found", file=sys.stderr)
            return 1
        
        # Load issue
        issue = Issue.from_dict(issue_dict)
        
        # Parse tags
        add_tags = None
        remove_tags = None
        if args.add_tags:
            add_tags = [tag.strip() for tag in args.add_tags.split(",")]
        if args.remove_tags:
            remove_tags = [tag.strip() for tag in args.remove_tags.split(",")]
        
        # Update issue
        issue.update(
            title=args.title,
            description=args.description,
            add_tags=add_tags,
            remove_tags=remove_tags
        )
        
        # Save
        store.update(args.id, issue.to_dict())
        
        print(f"Updated issue: {args.id}")
        print_issue_summary(issue.to_dict())
        
        return 0
        
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except OSError as e:
        print(f"Storage error: {e}", file=sys.stderr)
        return 2


def cmd_close(args) -> int:
    """Close an issue.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        issue_dict = store.get(args.id)
        
        if issue_dict is None:
            print(f"Error: Issue {args.id} not found", file=sys.stderr)
            return 1
        
        # Load and close issue
        issue = Issue.from_dict(issue_dict)
        issue.close()
        
        # Save
        store.update(args.id, issue.to_dict())
        
        print(f"Closed issue: {args.id}")
        
        return 0
        
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_reopen(args) -> int:
    """Reopen a closed issue.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        issue_dict = store.get(args.id)
        
        if issue_dict is None:
            print(f"Error: Issue {args.id} not found", file=sys.stderr)
            return 1
        
        # Load and reopen issue
        issue = Issue.from_dict(issue_dict)
        issue.reopen()
        
        # Save
        store.update(args.id, issue.to_dict())
        
        print(f"Reopened issue: {args.id}")
        
        return 0
        
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_search(args) -> int:
    """Search issues by text query.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        
        # Parse tags
        tags = None
        if args.tags:
            tags = [tag.strip() for tag in args.tags.split(",")]
        
        # Search
        status = args.status if args.status != "all" else None
        issues = search_issues(store, query=args.query, tags=tags, status=status)
        
        if not issues:
            print("No issues found matching search criteria.")
            return 0
        
        # Display
        print(f"Found {len(issues)} issue(s):\n")
        for issue in issues:
            print_issue_summary(issue)
            print()
        
        return 0
        
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_report(args) -> int:
    """Generate a markdown report.
    
    Args:
        args: Parsed command-line arguments
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        store = get_store(args.db_path)
        
        # Get issues with optional status filter
        status = args.status if args.status != "all" else None
        issues = search_issues(store, status=status)
        
        # Generate report
        report = generate_report(issues, group_by=args.group_by)
        
        # Output
        if args.output:
            # Validate output path
            _validate_output_path(args.output)
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(report)
            print(f"Report written to: {args.output}")
        else:
            print(report)
        
        return 0
        
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def _validate_output_path(file_path: str) -> None:
    """Validate output file path is safe.
    
    Args:
        file_path: Path to validate
    
    Raises:
        ValueError: If path is invalid or outside allowed directories
    """
    from pathlib import Path
    
    try:
        resolved = Path(file_path).resolve()
        home = Path.home().resolve()
        cwd = Path.cwd().resolve()
        
        # Allow paths within home directory or current working directory
        if not (str(resolved).startswith(str(home)) or str(resolved).startswith(str(cwd))):
            raise ValueError(
                f"Output path must be within home directory or current directory"
            )
    except (OSError, RuntimeError) as e:
        raise ValueError(f"Invalid output path: {e}")


def print_issue_summary(issue: dict) -> None:
    """Print a summary of an issue.
    
    Args:
        issue: Issue dictionary
    """
    issue_id = issue.get("id", "unknown")[:8]
    title = issue.get("title", "Untitled")
    status = issue.get("status", "unknown")
    tags = issue.get("tags", [])
    
    print(f"[{issue_id}] {title}")
    print(f"  Status: {status}")
    if tags:
        print(f"  Tags: {', '.join(tags)}")


def print_issue_detail(issue: dict) -> None:
    """Print detailed information about an issue.
    
    Args:
        issue: Issue dictionary
    """
    print(f"ID: {issue.get('id', 'unknown')}")
    print(f"Title: {issue.get('title', 'Untitled')}")
    print(f"Status: {issue.get('status', 'unknown')}")
    print(f"Created: {issue.get('created_at', 'unknown')}")
    print(f"Updated: {issue.get('updated_at', 'unknown')}")
    
    tags = issue.get("tags", [])
    if tags:
        print(f"Tags: {', '.join(tags)}")
    else:
        print("Tags: (none)")
    
    print("\nDescription:")
    description = issue.get("description", "")
    if description:
        print(description)
    else:
        print("(no description)")


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser with all subcommands.
    
    Returns:
        Configured ArgumentParser
    """
    parser = argparse.ArgumentParser(
        prog="issue-tracker",
        description="Mini Issue Tracker - A lightweight issue tracking system"
    )
    
    parser.add_argument(
        "--db-path",
        help="Path to database file (default: ~/.issue_tracker/issues.json)"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Create command
    create_parser = subparsers.add_parser("create", help="Create a new issue")
    create_parser.add_argument("--title", required=True, help="Issue title")
    create_parser.add_argument("--description", help="Issue description")
    create_parser.add_argument("--tags", help="Comma-separated tags")
    create_parser.set_defaults(func=cmd_create)
    
    # List command
    list_parser = subparsers.add_parser("list", help="List issues")
    list_parser.add_argument("--status", choices=["open", "closed", "all"], default="all", help="Filter by status")
    list_parser.add_argument("--tags", help="Filter by comma-separated tags")
    list_parser.add_argument("--sort", choices=["created", "updated", "title"], default="created", help="Sort by field")
    list_parser.add_argument("--reverse", action="store_true", help="Reverse sort order")
    list_parser.set_defaults(func=cmd_list)
    
    # Show command
    show_parser = subparsers.add_parser("show", help="Show issue details")
    show_parser.add_argument("id", help="Issue ID")
    show_parser.set_defaults(func=cmd_show)
    
    # Update command
    update_parser = subparsers.add_parser("update", help="Update an issue")
    update_parser.add_argument("id", help="Issue ID")
    update_parser.add_argument("--title", help="New title")
    update_parser.add_argument("--description", help="New description")
    update_parser.add_argument("--add-tags", help="Comma-separated tags to add")
    update_parser.add_argument("--remove-tags", help="Comma-separated tags to remove")
    update_parser.set_defaults(func=cmd_update)
    
    # Close command
    close_parser = subparsers.add_parser("close", help="Close an issue")
    close_parser.add_argument("id", help="Issue ID")
    close_parser.set_defaults(func=cmd_close)
    
    # Reopen command
    reopen_parser = subparsers.add_parser("reopen", help="Reopen a closed issue")
    reopen_parser.add_argument("id", help="Issue ID")
    reopen_parser.set_defaults(func=cmd_reopen)
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search issues")
    search_parser.add_argument("--query", help="Text search query")
    search_parser.add_argument("--tags", help="Filter by comma-separated tags")
    search_parser.add_argument("--status", choices=["open", "closed", "all"], default="all", help="Filter by status")
    search_parser.set_defaults(func=cmd_search)
    
    # Report command
    report_parser = subparsers.add_parser("report", help="Generate markdown report")
    report_parser.add_argument("--output", help="Output file (default: stdout)")
    report_parser.add_argument("--status", choices=["open", "closed", "all"], default="all", help="Filter by status")
    report_parser.add_argument("--group-by", choices=["status", "tags", "none"], default="status", help="Grouping strategy")
    report_parser.set_defaults(func=cmd_report)
    
    return parser


def main() -> int:
    """Main entry point for CLI.
    
    Returns:
        Exit code
    """
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
