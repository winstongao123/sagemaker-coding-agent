# Test file
VERSION = "1.0.0"
print("hello")
